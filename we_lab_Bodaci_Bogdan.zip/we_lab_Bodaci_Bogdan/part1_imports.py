# Laborator : functii, metode  si importuri pe web
# Student : Bodaci Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #SECUNDE

#Exercitiul 1
import requests
import  urllib.request
print("Veriunea afisata: ", requests.__version__)

#urllib este o biblioteca standart inclusa in python
#request este o biblioteca third-party dezvoltata extern de o comunitate
#de aia requestul are nevoie de pip install

#####################################################

#Exercitiul 2

import requests
import urllib.request
response = requests.get(BASE_URL)
print("Stilul 1 - status code: ", response.status_code)
from requests import get
response = get(BASE_URL)
print("Stilul 2 -status code: ", response.status_code)

#Ambele stiuluri dau fix acelasi output.
#Pirn stilul 1 am vazut ca singurul lucru e ca dai comanda deplina de request.get si care dupa iti da raspunsul, deoarece trebuie sa definesti comanda.
#In stilul 2, requestul este deja importat si  prin asta din libraria request importam get si in loc sa cautam in libraria request comanda get, noi pur si simplu dam get si atat.
#a doua comanda e mai comoda, dar cred ca inceputul mereu trebuie sa fie ceva ca oricine sa poata incetelege ce fac si ce am facut.

####################################################

#Exercitiul 3

import requests as rq
response = rq.get(BASE_URL)
print(response)

#Alias-ul rq e util cand numele librariei este lung si vrei sa scrii codul mai rapid
#Poate fi mai greu de citit daca cineva strain se uia pe cod si nu stie ce inseamna

####################################################

#Exercitiul 4
print()
import urllib.request
req = urllib.request.Request(BASE_URL, headers={'User-Agent' : 'Mozilla/5.0'})
response = urllib.request.urlopen(req)
print(response.status)
bytes = response.read()
text = bytes.decode("utf-8")
print(text[:200])




###################################################

#Exercitiul 5
print()
import requests
print(dir(requests))

#Din lista obtonute am ales 3 nume:
#1.(get) care este o functie(o apelam sa facem o cerere)
#2.(Response) care este o clasa(obiectul care il primim ca raspuns)
#3.(exceptions) care este un modul intern(contine tipurile de erori)


###################################################

#Exercitiul 6
print()
import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("status code este:", response.status_code)

#Parametrul care seteaza timpul maxim este TIMEOUT

###################################################

#Exercitiul 7

import time
import requests
t_start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
t_end =  time.perf_counter()
durata_noastra = t_end - t_start
durata_server = response.elapsed.total_seconds()
print(f"Timp masurat de catre noi : {durata_noastra:.4f} secunde")
print(f"Timp inregistrat de server : {durata_server:.4f} secunde")

#perf_counter masoarea tot timpul procesului
#response.elapsed masoara doar timpul din momentul trimiterii pana la primirea primilor octeti de la sever

###################################################

#Exercitiul 8

try:
    import bs4
except ImportError:
    print("Instalati modul cu: pip install beautifulsoup4")

###################################################
