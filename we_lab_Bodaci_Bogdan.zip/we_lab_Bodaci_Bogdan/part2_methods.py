#Laborator : functii, metode si importuri pe web
#Student : Bodaci Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

################################################

#Exercitiul 9

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("status_code:", response.status_code) #Atribut, deoarece este o valoare sau numar
print("ok:", response.ok) #Atribut, deoarece este True sau False
print("url:", response.url) #Atribut, deoarece este un text cu adresa
print("encoding:", response.encoding) #Atribut, deoarece este tipul de codificare

##############################################

#Exercitiul 10

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
response.raise_for_status()
try:
   bad_res = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
   bad_res.raise_for_status()
except requests.HTTPError as e:
     print("Pagina nu exista! Am prins eroarea fara sa crape programul:", e)

################################################

#Exercitiul 11

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Toate antenele:")
for cheie, valoare in response.headers.items():
   print(f"{cheie}: {valoare}")

###############################################

#Exercitiul 12

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
server_hdr = response.headers.get("Server","lipseeste")
content_type_hdr = response.headers.get("Content-Type", "lipseste")
lower_hdr = response.headers.get("content-type", "lipseste")
print(f"Server: {server_hdr}")
print(f"Content-Type: {content_type_hdr}")
print(f"content-type: {lower_hdr}")

#Am observat ca in ambele cazuri content-type e scris de amandoua ori cu litere mici, serverul cloudlare si ambele content typuri la fel.

#####################################################################

#Exercitiul 13

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
numar_cyber = response.text.lower().count("cyber")
print(f"Cuvantul 'cyber' apare de {numar_cyber} ori pe pagina.")

#Putem inlantui .lower() si .count() pentru ca response.text returneaza un stirng, .lower() transforma stringul in litere mici si returneaza tot un string, iar pe noul stirng putem apela direct cu .count()

#####################################################################

#Exercitiul 14

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
if start != -1 and end != -1:
   titlu = html[start:end].strip()
   print("Titlul extras din pagina", titlu)

########################################################

#Exercitiul 15

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text
linii = html.splitlines()
cea_mai_lunga = max(linii, key=len) if linii else ""
print(f"Numar total de linii: {len(linii)}")
print(f"Lunfimea celei mai lungi linii: {len(cea_mai_lunga)} caractere")

########################################################################

#Exercitiul 16

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
if response.url.startswith("https://"):
   print("Conexiune securizata")
else:
    print("Conexiune nesecurizata")

##################################################

#Exercitiul 17

import requests
res_redir = requests.get(BASE_URL, timeout=TIMEOUT)
print("Istoric redirectionari:")
for r in res_redir.history:
   print(f"{r.status_code} -> {r.url}")
print("URL final:", res_redir.url)

###################################################

#Exercitiul 18

import requests
res_head = requests.head(BASE_URL, timeout=TIMEOUT)
res_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("Dimensiunea corp la head:", len(res_head.content))
print("Dimensiunea corp la get:", len(res_get.content))

#head cere doar antenele paginii, fara sa descarce continutul
#get descarca tot continutul html al paginii

#########################################################

#Exercitiul 19

import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cookiuri:")
if response.cookies:
   for c in response.cookies:
       print(f"Nume: {c.name}, Secure: {c.secure}")
else:
    print("Nici un cookie setat")

#######################################################

#Exercitiul 20

import requests
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-BodaciBogdan"})
res_sess = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
user_agent_primit = res_sess.json()["headers"].get("User-Agent")
print("User-Agent primit inapoi de la server:", user_agent_primit)

###################################################################
