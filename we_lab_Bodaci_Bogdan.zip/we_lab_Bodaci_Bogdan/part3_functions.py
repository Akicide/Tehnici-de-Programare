# Laborator : functii, metode si importuri pe web
# Student : Bodaci Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

##################################################

#Exercitiul 21

import requests
def fetch(url):
         """Face o cerere get catre url si returneaza obiectul response"""
         return requests.get(url, timeout=TIMEOUT)
response = fetch(BASE_URL)
print("response status:", response.status_code)

###################################################

#Exercitiul 22

import requests
import time
def get_status(url):
             """Returneaza doar codul de stare http pentru adresa url """
             response = requests.get(url, timeout=TIMEOUT)
             return response.status_code
cai = ["/", "/robots.txt", "/sitemap.xml"]
for cale in cai:
         print(f"Status pentru {cale}: {get_status(BASE_URL + cale)}")
         time.sleep(1)

######################################################################

#Exercitiul 23

import requests
def fetch_p3(url, timeout=10):
             """Face o cerere get cu valoare implicita pentru timeout """
             return requests.get(url, timeout=TIMEOUT)
res_implicit = fetch_p3(BASE_URL)
res_custom = fetch_p3(BASE_URL, timeout=3)
print(f"Apelarea: {res_implicit}, {res_custom}")

############################################################################

#Exercitiul 24 si 25

import requests
def get_title(html):
             """Extrage si curata textul titlului dintrun cod html.
    parametri:
        html : codul html al paginii.
    returneaza:
        str: titlul curatat de spatii libere.
    """
             start = html.find("<title>")
             end = html.find("/<title>")
             if start != -1 and end != -1:
                       return html[start + len("<title>"):end].strip()
             return ""

########################################################################

#Exercitiul 26

import requests
def get_status_typed(url: str) -> int:
             """Returneaza codul de stare folosind adnotari de tip"""
             response = requests.get(url, timeout=TIMEOUT)
             return response.status_code

# Daca apelam get_status_typed(123), Python nu ne opreste si ruleaza codul mai departe
# pentru ca adnotarile sunt doar informative pentru editor de cod. 

######################################################################################

#Exercitiul 27

import requests

def page_exists(url):
    """Verifica daca o pagina exista si returneaza True sau False fara sa opreasca programul."""
    try:
        res = requests.get(url, timeout=TIMEOUT)
        return res.status_code == 200
    except requests.RequestException:
        return False

print("Exista domeniul fals?:", page_exists("https://this-domain-does-not-exist.invalid"))

#####################################################################################################

#Exercitiul 28

import requests
import time
def check_paths(base,paths):
         """Primeste o lista de cai si returneaza un dictionar cu statusul fiecareia."""
         rezultate = {}
         for p in paths:
               url_complet = base.rstrip("/") + p
               try:
                  response = requests.get(url_complet, timeout=TIMEOUT)
                  rezultate[p] = response.status_code
               except requests.RequestsException:
                   rezultate[p] = 0
               time.sleep(1)
         return rezultate

print("Verificare cai:", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))

######################################################################################################

#Exercitiul 29

import requests
def get_header(url, name, defaults="lipseste"):
              """Returneaza valoarea unui singur antet din raspuns."""
              try:
                 response = requests.get(url, timeout=TINMEOUT)
                 return res.headers.get(name, defaults)
              except:
                 return defaults
print("antet server cu argument numit:", get_header(BASE_URL, name="Server"))

################################################################################

#Exercitiul 30

import requests
def security_headers(url):
    """Verifica prezenta celor 5 antete de securitate."""
    antete_verificate = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        res = requests.get(url, timeout=TIMEOUT)
        return {h: h in res.headers for h in antete_verificate}
    except requests.RequestException:
        return {h: False for h in antete_verificate}

#####################################################################

#Exercitiul 31

import requests
def score_headers(results):
         """Calculeaza scorul antetelor de securitate in format '3/5'."""
         gasite = sum(1 for prezent in results.values() if prezent)
         return f"{gasite}/{len(results)}"
print("Scor securitate cybercor:", score_headers(security_headers(BASE_URL)))

################################################################################

# Exercitiul 32

import requests
def fetch_robots(base):
    """Descarca robots.txt sau returneaza None daca nu il gaseste."""
    url = base.rstrip("/") + "/robots.txt"
    try:
        res = requests.get(url, timeout=TIMEOUT)
        if res.status_code == 200:
            return res.text
        return None
    except requests.RequestException:
        return None
def disallowed_paths(robots_text):
    """Extrage o lista cu toate caile Disallow: din robots.txt."""
    if not robots_text:
        return []
    cai_interzise = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.lower().startswith("disallow:"):
            parti = linie.split(":", 1)
            if len(parti) > 1 and parti[1].strip():
                cai_interzise.append(parti[1].strip())
    return cai_interzise
print("Cai interzise in robots.txt:", disallowed_paths(fetch_robots(BASE_URL)))

#################################################################################

# Exercitiul 33

import time
import requests
def response_times(*urls):
    """Masoara timpul de raspuns pentru oricate URL-uri primeste."""
    rezultate = {}
    for url in urls:
        t_start = time.perf_counter()
        try:
            requests.get(url, timeout=TIMEOUT)
            t_total = time.perf_counter() - t_start
            rezultate[url] = round(t_total, 4)
        except requests.RequestException:
            rezultate[url] = -1.0
        time.sleep(1)
    return rezultate
print("Timpi de raspuns:", response_times(BASE_URL, ECHO_URL))

######################################################################

# Exercitiul 34

def log(message, **details):
    """Afiseaza mesajul si detaliile primite ca argumente cu nume."""
    detalii_formatate = " | ".join(f"{k}={v}" for k, v in details.items())
    if detalii_formatate:
        print(f"{message} | {detalii_formatate}")
    else:
        print(message)
log("verificat", url=BASE_URL, status=200)

##########################################################################
