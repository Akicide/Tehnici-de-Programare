# Laborator: funcții, metode și importuri pe web
# Student: Bodaci Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

##################################################

#Exercitiul 44 si 45

from webtools import get_title, security_headers

#Daca main.py ar fi defini o functie locala cu acelasi nume,
#functia importanta din webtools ar fi suprascrisa.

#############################################################

#Exercitiul 47

from webtools import DEFAULT_HEADERS
print("DEAFULT_HEADERS importat:", DEFAULT_HEADERS)

####################################################

#Exercitiul 48

import argparse
parser = argparse.ArgumentParser(description="Analizor site web")
parser.add_argument("url", nargs="?", default="https://cybercor.org", help="url de analizat")
args = parser.parse_args()
target_url = args.url

###########################################################################################################

#Exercitiul 49

import csv
import datetime
import webtools
cai = ["/", "/robots.txt", "/sitemap.xml"]
with open("report.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["path", "status", "checked_at"])
    for c in cai:
        st = webtools.get_status(target_url.rstrip("/") + c)
        writer.writerow([c, st, datetime.datetime.now().isoformat()])
print("Raportul csv a fost salvat in report.csv")

######################################################################

#Exercitiul 50

import webtools
webtools.site_report(target_url)

####################################
