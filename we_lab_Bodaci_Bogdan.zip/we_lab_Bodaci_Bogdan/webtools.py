# Laborator : functii, metode si importuri pe web
# Student : Bodaci Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-BodaciBogdan"}

##################################################

#Exercitiul 44 si 47

def fetch(url, timeout=TIMEOUT):
    """Face o cerere get cu antetele noastre implicate"""
    import requests
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)

######################################################################

#Exercitiul 44 si 46

def get_status(url):
    """Returneaza codul de stare http"""
    import requests
    try:
        res = fetch(url)
        return res.status_code
    except:
        return 0

##############################################

#Exercitiul 44

def get_title(html):
    """Extrage titlul dintrun text html"""
    start = html.find("<title>")
    end = html.find("</title>")
    if start != -1 and end != -1:
        return html[start + len("<title>"):end].strip()
    return "Fara titlu"

#########################################################

#exercitiul 44 si 50
def security_headers(url):
    """Verifica antetele de securitate"""
    import requests
    antete = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    try:
        res = fetch(url)
        return {h: h in res.headers for h in antete}
    except:
        return {h: False for h in antete}

#########################################################

#Exercitiul 50, scor antete
def score_headers(results):
    """Calculeaza scorul de securitate"""
    return f"{sum(1 for v in results.values() if v)}/{len(results)}"
    
#################################################################

#Exercitiul 50, preluare robot.txt

def fetch_robots(base):
    """Descarca fisierul /robots.txt"""
    import requests
    try:
        res = fetch(base.rstrip("/") + "/robots.txt")
        return res.text if res.status_code == 200 else None
    except requests.RequestException:
        return None

#############################################################

#Exercitiul 50, cai interzise

def disallowed_paths(robots_text):
    """Extrage caile disallow din robots.txt"""
    if not robots_text:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.strip().lower().startswith("disallow"):
            parts = line.split(":", 1)
            if len(parts) > 1 and parts[1].strip():
                paths.append(parts[1].strip())
    return paths

##########################################################

#Exercitiul 50, zile certificate ssl

def cert_days_left(hostname):
    """Returneaza zilele ramase pentru certificatul ssl"""
    import socket
    import ssl
    import datetime
    context = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                exp = datetime.datetime.fromtimestamp(ssl.cert_time_to_seconds(cert['notAfter']), tz=datetime.timezone.utc)
                return (exp - datetime.datetime.now(tz=datetime.timezone.utc)).days
    except Exception:
        return 0

##########################################################################################################################

#Exercitiul 50 final

def site_report(url):
    """Genereaza raportul complet al sitului si il salveaza in report.json"""
    import urllib.parse
    import socket
    import re
    import json
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.netloc or parsed.path
    res = fetch(url)
    status_code = res.status_code
    final_url = res.url
    titlu = get_title(res.text)
    try:
        ip = socket.gethostbyname(hostname)
    except:
        ip = "N/A"

    try:
        res_http = fetch(f"http://{hostname}")
        redirects = [f"{r.status_code} -> {r.url}" for r in res_http.history]
        redir_text = ", ".join(redirects) if redirects else f"Niciuna ({res_http.status_code})"
    except Exception:
        redir_text = "Eroare rediriconare"
    sec_res = security_headers(url)
    sec_score = score_headers(sec_res)
    zile_cert = cert_days_left(hostname)
    raw_links = list(set(re.findall(r'href="([^"]+)"', res.text)))
    interne, externe = [], []
    for l in raw_links:
        full = urllib.parse.urljoin(BASE_URL, l)
        if urllib.parse.urlparse(full).netloc == hostname:
            interne.append(full)
        else:
            externe.append(full)
            
    robots = fetch_robots(url)
    interzise = disallowed_paths(robots)
    raport = {
        "target_url": url,
        "status_code": status_code,
        "final_url": final_url,
        "title": titlu,
        "ip_address": ip,
        "redirects": redir_text,
        "security_score": sec_score,
        "cert_days_left": zile_cert,
        "internal_links_count": len(interne),
        "external_links_count": len(externe),
        "disallowed_paths": interzise
    }
    with open("report.json", "w", encoding="utf-8") as f:
        json.dump(raport, f, indent=2, ensure_ascii=False)
    print(f"Raport site: {url}")
    print(f"Cod de stare: {status_code}")
    print(f"Titulu: {titlu}")
    print(f"Adresa IP: {ip}")
    print(f"Redirectionare: {redir_text}")
    print(f"Scor securitate: {sec_score}")
    print(f"Certificat: {zile_cert} de zile ramase")
    print(f"Legaturi: {len(interne)} interne, {len(externe)} externe")
    print(f"Cai interzise: {', '.join(interzise) if interzise else 'Niciuna'}")
    print("Salvat in report.json")
    return raport
####################################################################################

#Exercitiul 46, blocul main pentru autotest

if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))


##########################################################
