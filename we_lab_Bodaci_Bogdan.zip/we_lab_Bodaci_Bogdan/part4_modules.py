# Laborator : functii, metode si importuri pe web
# Student : Bodaci Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

##################################################

#Exercitiul 35

import urllib.parse
parsed = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")
print("scheme:", parsed.scheme)
print("netloc:", parsed.netloc)
print("path:", parsed.path)
print("query:", parsed.query)
print("fragment:", parsed.fragment)

###################################################################

#Exercitiul 36

import urllib.parse
for legatura in ["/about", "contact.html", "../index.html"]:
    url_absolut = urllib.parse.urljoin(BASE_URL, legatura)
    print(f"Legatura transformata pentru {legatura}: {url_absolut}")

#####################################################################

#Exercitiul 37

import re
def extract_links(html):
    """Extrage toate legaturile href din html"""
    legaturi = re.findall(r'href="([^"]+)"', html)
    return list(set(legaturi))

##########################################################

#Exercitiul 38

import urllib.parse
def split_links(links,domain):
    """Separa legarurile interne si externe"""
    interne = []
    externe = []
    domeniu_baza = urllib.parse.urlparse(domain).netloc

    for link in links:
        url_complet = urllib.parse.urljoin(domain, link)
        domeniu_link = urllib.parse.urlparse(url_complet).netloc
        if domeniu_link == domeniu_baza:
            interne.append(url_complet)
        else:
            externe.append(url_complet)
    return interne, externe

##################################################################

#Exercitiul 39

from html.parser import HTMLParser
import requests
class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []
    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            valoare_src = dict(attrs).get("src")
            if valoare_src:
                self.images.append(valoare_src)
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print(finder.images)

assert finder.images == [
    "/logo.png",  # imagine obișnuită
    "poza.jpg",  # tag scris cu majuscule
    "https://cdn.example.com/banner.webp",  # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

res_real = requests.get(BASE_URL, timeout=TIMEOUT)
finder_real = ImageFinder()
finder_real.feed(res_real.text)
print(len(finder_real.images), "imagini gasite pe site-ul real")

##########################################################################

#Exercitiu 40

import hashlib
import requests
def page_fingerprint(url):
    """Returneaza hash SHA-256 al continutului paginii"""
    res = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(res.content).hexdigest()
print("Hash 1:", page_fingerprint(BASE_URL))
print("Hash 2:", page_fingerprint(BASE_URL))

#Rezultatele pot fi diferite daca intre timp sa schimbat ceva pe server

#######################################################################

#Exeritiul 41

import json
import requests
res_headers = requests.get(BASE_URL, timeout=TIMEOUT)
with open("header.json","w", encoding="utf-8") as f:
    json.dump(dict(res_headers.headers), f, indent=2)
with open("header.json","r", encoding="utf-8") as f:
    date_incarcate = json.load(f)
print("Antet incarcat din fisier:", date_incarcate.get("Content-Type"))

########################################################################

#Exercitiul 42

import socket
def reslove(hostname):
    """Afla adresa IP pentru un nume de domeniu"""
    return socket.gethostbyname(hostname)
print("IP cybercor.org:", reslove("cybercor.org"))

##################################################

#Exercitiul 43

import socket
import ssl
import datetime
def cert_days_left(hostname):
    """Citeste certificatul ssl si returneaza cate zile mai sunt valabile"""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            timestamp = ssl.cert_time_to_seconds(cert["notAfter"])
            data_expirare = datetime.datetime.fromtimestamp(timestamp, tz=datetime.timezone.utc)
            acum = datetime.datetime.now(tz=datetime.timezone.utc)
            return (data_expirare - acum).days
print("zile ramase certificat:", cert_days_left("cybercor.org"))

##################################################################################################

